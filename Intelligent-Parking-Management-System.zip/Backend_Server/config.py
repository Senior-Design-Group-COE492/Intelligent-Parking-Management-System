import os

#setting env variable
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.path.abspath("./parkingapp-6ecfd-firebase-adminsdk-4dxe4-9280754b4c.json")
