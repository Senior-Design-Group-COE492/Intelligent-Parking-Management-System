# Backend Server

# TO DO #

# 1) Fetch from API parking info --> Use Saif's function
# 2) Update parking info on firebase 
# 3) Send list of filtered parking locations back to search request -->
# 4) Get Prediction -> send prediction to client
# 5) Generate prediction
# 6)
